<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ArtDos</title>
	<meta name="description" content="Art">
	<meta name="keywords" content="art, photo">
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css?family=Nunito&display=swap" rel="stylesheet">
</head>
<body>
<form action="/signup.php" method="POST">
	<p>
		<p><strong>Pick a username</strong></p>
		<input type="text" name="login">
	</p>

</form>
</body>
</html>